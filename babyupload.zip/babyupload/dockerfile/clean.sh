rm -rf /var/www/html/upload/*
sleep 3s
nohup /bin/bash /clean.sh &
