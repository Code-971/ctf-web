# 题目：php文件上传

### 题目描述：只准上传gif文件的

### 题目难度： 🌟

### 维护：SiJiDo

### KEY: `flag{ffffffffllllaaggg_!!!}`

### 配置信息： 


### 解题过程：

1. 修改content-type为image/gif即可
2. 利用shell查看flag.php