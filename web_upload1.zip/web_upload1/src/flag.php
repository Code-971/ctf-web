<?php
	$flag = "flag{ffffffffllllaaggg_!!!}";